Rails.application.routes.draw do
  #devise_for :users

  devise_for :users
  devise_scope :user do
    get '/users/sign_out' => 'devise/sessions#destroy'
  end


  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  resources :skirts
  resources :blouses
  resources :shoes
  resources :pants



=begin
  get "/articles" index
  post "/articles" create
  delete "/articles" delete
  get "/articles/:id" show
  get "/articles/new" new
  get "/articles/:id/edit" edit
  patch "/articles/:id/edit" update
  put "/articles/:id" update

=end

  root 'welcome#index'
  root 'blouses#show'
  root 'blouses#edit'
  root 'blouses#new'


  root 'shoes#show'
  root 'shoes#edit'
  root 'shoes#new'

  root 'skirts#show'
  root 'skirts#edit'
  root 'skirts#new'

  root 'pants#show'
  root 'pants#edit'
  root 'pants#new'



end
