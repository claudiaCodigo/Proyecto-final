require 'test_helper'

class SkirtTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
