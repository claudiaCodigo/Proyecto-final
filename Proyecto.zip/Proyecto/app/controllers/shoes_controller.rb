class ShoesController < ApplicationController


# GET /articles
  def index

    @shoes = Shoe.all
  end

# GET /articles/:id
  def show

    @shoe = Shoe.find(params[:id])

  end

# GET /articles/new
  def new

    @shoe = Shoe.new

  end

  # GET /articles/id/edit - 23/10/18
    def edit

      @shoe = Shoe.find(params[:id])

    end


  # GET /articles/id/update -23/10/18

     def update
       @shoe = Shoe.find(params[:id])

  if @shoe.update(shoe_params) #la variable libro_params viene del controlador declarado hasta abajo que es para validar los datos

  redirect_to @shoe

  else
    render :edit

  end
    end


 #POST /articles
  def create

    @shoe = current_user.shoes.new(shoe_params)

    if @shoe.save
    redirect_to @shoe

  else

    render :new
  end
end

def destroy

  @shoe = Shoe.find(params[:id])
  @shoe.destroy

  redirect_to shoes_path

end




#23/10/18 - Proteccion de datos

private

def shoe_params

params.require(:shoe).permit(:tipo, :marca, :color, :talla, :cantidad, :precio)

end


end
