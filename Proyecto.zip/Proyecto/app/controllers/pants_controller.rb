class PantsController < ApplicationController


# GET /articles
  def index

    @pants = Pant.all
  end

# GET /articles/:id
  def show

    @pant = Pant.find(params[:id])

  end

# GET /articles/new
  def new

    @pant = Pant.new

  end

  # GET /articles/id/edit - 23/10/18
    def edit

      @pant = Pant.find(params[:id])

    end


  # GET /articles/id/update -23/10/18

     def update
       @pant = Pant.find(params[:id])

  if @pant.update(pant_params) #la variable libro_params viene del controlador declarado hasta abajo que es para validar los datos

  redirect_to @pant

  else
    render :edit

  end
    end


 #POST /articles
  def create

@pant = current_user.pants.new(pant_params)

    if @pant.save
    redirect_to @pant

  else

    render :new
  end
end

def destroy

  @pant = Pant.find(params[:id])
  @pant.destroy

  redirect_to pants_path

end




#23/10/18 - Proteccion de datos

private

def pant_params

params.require(:pant).permit(:tipo, :marca, :color, :talla, :cantidad, :precio)

end


end
