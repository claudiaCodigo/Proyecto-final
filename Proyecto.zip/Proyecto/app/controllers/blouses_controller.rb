class BlousesController < ApplicationController


# GET /articles
  def index

    @blouses = Blouse.all
  end

# GET /articles/:id
  def show

    @blouse = Blouse.find(params[:id])

  end

# GET /articles/new
  def new

    @blouse = Blouse.new

  end

  # GET /articles/id/edit - 23/10/18
    def edit

      @blouse = Blouse.find(params[:id])

    end


  # GET /articles/id/update -23/10/18

     def update
       @blouse = Blouse.find(params[:id])

  if @blouse.update(blouse_params) #la variable libro_params viene del controlador declarado hasta abajo que es para validar los datos

  redirect_to @blouse

  else
    render :edit

  end
    end


 #POST /articles
  def create

    @blouse = current_user.blouses.new(blouse_params)

    if @blouse.save
    redirect_to @blouse

  else

    render :new
  end
end

def destroy

  @blouse = Blouse.find(params[:id])
  @blouse.destroy

  redirect_to blouses_path

end




#23/10/18 - Proteccion de datos

private

def blouse_params

params.require(:blouse).permit(:tipo, :marca, :color, :talla, :cantidad, :precio)

end


end
