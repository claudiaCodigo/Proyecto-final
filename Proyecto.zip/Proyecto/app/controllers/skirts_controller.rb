class SkirtsController < ApplicationController


# GET /articles
  def index

    @skirts = Skirt.all
  end

# GET /articles/:id
  def show

    @skirt = Skirt.find(params[:id])

  end

# GET /articles/new
  def new

    @skirt = Skirt.new

  end

  # GET /articles/id/edit - 23/10/18
    def edit

      @skirt = Skirt.find(params[:id])

    end


  # GET /articles/id/update -23/10/18

     def update
       @skirt = Skirt.find(params[:id])

  if @skirt.update(skirt_params) #la variable libro_params viene del controlador declarado hasta abajo que es para validar los datos

  redirect_to @skirt

  else
    render :edit

  end
    end


 #POST /articles
  def create

    @skirt = current_user.skirts.new(skirt_params)

    if @skirt.save
    redirect_to @skirt

  else

    render :new
  end
end

def destroy

  @skirt = Skirt.find(params[:id])
  @skirt.destroy

  redirect_to skirts_path

end




#23/10/18 - Proteccion de datos

private

def skirt_params

params.require(:skirt).permit(:tipo, :marca, :color, :talla, :cantidad, :precio)

end


end
