class Blouse < ApplicationRecord

  belongs_to :user
end
