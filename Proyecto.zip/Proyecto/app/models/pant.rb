class Pant < ApplicationRecord

  belongs_to :user
end
