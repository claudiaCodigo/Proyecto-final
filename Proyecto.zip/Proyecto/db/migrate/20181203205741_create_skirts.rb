class CreateSkirts < ActiveRecord::Migration[5.1]
  def change
    create_table :skirts do |t|
      t.string :tipo
      t.string :marca
      t.string :color
      t.string :talla
      t.string :cantidad
      t.string :precio
      t.integer :visits_count

      t.timestamps
    end
  end
end
